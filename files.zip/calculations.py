"""
Core math for the Late-Stage Boundary Arbitrage edge test.

G(t, P) is a piece-wise required-gap threshold derived from a GBM diffusion
term, with the t <= 1.0 branch using a TWAP-settlement-adjusted power law
instead of the plain sqrt(t) term, to reflect that TWAP settlement averages
price over the final window rather than sampling a single terminal price.
"""

import math

from scipy.stats import norm


def compute_z_score(contract_price: float) -> float:
    """
    Dynamically compute the standard normal Z-score corresponding to the
    cumulative probability implied by the contract's decimal price.

    e.g. contract_price=0.75 -> z ~ 0.674
         contract_price=0.90 -> z ~ 1.282
    """
    return norm.ppf(contract_price)


def compute_required_gap(t: float, contract_price: float, sigma: float) -> float:
    """
    Piece-wise required boundary gap G(t, P):

        t > 1.0:   G = z * sigma * sqrt(t - 0.5)
        t <= 1.0:  G = z * sigma * sqrt(1/3) * t**1.5

    Note on sign: contract prices below 0.50 imply a negative z-score
    (norm.ppf(P) < 0 for P < 0.5), which would make G negative and the
    edge test (actual_gap >= G) trivially true for any non-negative
    actual_gap. Since G represents a required *distance*, this function
    returns the magnitude (abs) of the computed value. If your strategy
    intends asymmetric (signed) treatment for P < 0.5 contracts, adjust
    this function accordingly -- as written, sub-0.50 contracts are
    treated the same as their 1-P mirror image.
    """
    z = compute_z_score(contract_price)

    if t > 1.0:
        raw_gap = z * sigma * math.sqrt(t - 0.5)
    else:
        raw_gap = z * sigma * math.sqrt(1.0 / 3.0) * (t ** 1.5)

    return abs(raw_gap)


def compute_actual_gap(price: float, strike: float) -> float:
    """Absolute distance between current spot and the contract's strike."""
    return abs(price - strike)


def evaluate_edge(price: float, strike: float, t: float, contract_price: float, sigma: float) -> dict:
    """
    Run the full pipeline for a single webhook payload and return a dict
    with every intermediate value needed for logging and the edge verdict.
    """
    actual_gap = compute_actual_gap(price, strike)
    z_score = compute_z_score(contract_price)
    required_gap = compute_required_gap(t, contract_price, sigma)
    has_edge = bool(actual_gap >= required_gap)

    # scipy/numpy return numpy scalar types (np.float64, np.bool_) which the
    # stdlib json encoder cannot serialize -- cast everything to native
    # Python types before it leaves this function.
    return {
        "price": float(price),
        "strike": float(strike),
        "time_left": float(t),
        "contract_price": float(contract_price),
        "z_score": float(z_score),
        "actual_gap": float(actual_gap),
        "required_gap": float(required_gap),
        "has_edge": has_edge,
    }
