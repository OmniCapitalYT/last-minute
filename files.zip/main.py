"""
Late-Stage Boundary Arbitrage Alerting System
-----------------------------------------------
A hyper-lightweight FastAPI webhook server that:
  1. Accepts asset price ticks from TradingView (or any HTTP source) at POST /webhook
  2. Computes a piece-wise GBM/TWAP-adjusted required boundary gap G(t, P)
  3. Compares it against the actual observed price/strike gap
  4. Fires an async Telegram push notification the instant a +EV edge appears

Run directly with:  python -m app.main
Or via uvicorn:      uvicorn app.main:app --host 0.0.0.0 --port 8000
"""

import logging
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import JSONResponse
from typing import Optional

from app.config import CONFIG
from app.models import WebhookPayload, EvaluationResult
from app.calculations import evaluate_edge
from app.notifier import send_telegram_alert

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
)
logger = logging.getLogger("boundary_arb")

app = FastAPI(
    title="Late-Stage Boundary Arbitrage Alerting System",
    description="Webhook listener that evaluates GBM/TWAP boundary edges and dispatches Telegram alerts.",
    version="1.0.0",
)


@app.get("/")
async def health_check():
    """Simple liveness probe -- useful for host platforms (Render, etc.) that ping '/'."""
    return {
        "status": "online",
        "service": "boundary-arb-alerts",
        "sigma": CONFIG["SIGMA"],
        "time_utc": datetime.now(timezone.utc).isoformat(),
    }


@app.post("/webhook", response_model=EvaluationResult)
async def webhook(payload: WebhookPayload, x_webhook_secret: Optional[str] = Header(default=None)):
    # Optional shared-secret guard. Enable by setting WEBHOOK_SECRET in your
    # environment; TradingView must then send a matching X-Webhook-Secret header.
    configured_secret = CONFIG["WEBHOOK_SECRET"]
    if configured_secret and x_webhook_secret != configured_secret:
        raise HTTPException(status_code=401, detail="Invalid or missing webhook secret.")

    try:
        result = evaluate_edge(
            price=payload.price,
            strike=payload.strike,
            t=payload.time_left,
            contract_price=payload.contract_price,
            sigma=CONFIG["SIGMA"],
        )
    except Exception as exc:
        logger.exception("Error evaluating boundary edge calculation")
        raise HTTPException(status_code=400, detail=f"Calculation error: {exc}")

    logger.info(
        "EVAL | Spot=%.4f | Strike=%.4f | t=%.4f min | P=%.4f | Z=%.4f | ActualGap=%.4f | RequiredGap=%.4f | Edge=%s",
        result["price"],
        result["strike"],
        result["time_left"],
        result["contract_price"],
        result["z_score"],
        result["actual_gap"],
        result["required_gap"],
        result["has_edge"],
    )

    if result["has_edge"]:
        message = (
            "\U0001F6A8 *Boundary Arb Edge Detected*\n"
            f"Spot: `{result['price']}`\n"
            f"Strike: `{result['strike']}`\n"
            f"Time Left: `{result['time_left']} min`\n"
            f"Contract P: `{result['contract_price']}`\n"
            f"Actual Gap: `{result['actual_gap']:.4f}`\n"
            f"Required Gap: `{result['required_gap']:.4f}`"
        )
        await send_telegram_alert(message)

    return JSONResponse(content=result)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host=CONFIG["HOST"], port=CONFIG["PORT"], reload=False)
