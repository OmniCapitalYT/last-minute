"""
Request/response schemas for the boundary arbitrage webhook.
"""

from pydantic import BaseModel, Field


class WebhookPayload(BaseModel):
    """
    Matches the exact packet shape sent by TradingView:
    {"price": 59012.50, "strike": 59000.00, "time_left": 1.0, "contract_price": 0.75}
    """

    price: float = Field(..., gt=0, description="Current spot price of the underlying asset")
    strike: float = Field(..., gt=0, description="Target contract strike price")
    time_left: float = Field(..., gt=0, description="Time remaining until expiration, in minutes (fractions allowed)")
    contract_price: float = Field(
        ..., gt=0, lt=1, description="Contract entry price as a decimal probability, e.g. 0.75 for 75 cents"
    )


class EvaluationResult(BaseModel):
    price: float
    strike: float
    time_left: float
    contract_price: float
    z_score: float
    actual_gap: float
    required_gap: float
    has_edge: bool
