"""
Centralized configuration for the Late-Stage Boundary Arbitrage alerting system.

All values are sourced from environment variables first, with safe fallback
defaults so the service can boot in a dev environment without a .env file.
Override these in production via your host's environment variable settings
(Render, PythonAnywhere, Docker, systemd, etc.) rather than editing this file.
"""

import os

CONFIG = {
    # Baseline per-minute volatility anchor. Default 20.0 is tuned for BTC.
    # Override per-asset by setting the SIGMA env var at deploy time, or by
    # extending the payload to carry a per-request sigma if you trade
    # multiple assets from one deployment.
    "SIGMA": float(os.getenv("SIGMA", "20.0")),

    # Telegram Bot API credentials. Create a bot via @BotFather to get a
    # token, and message @userinfobot (or use getUpdates) to find your
    # numeric chat_id.
    "TELEGRAM_BOT_TOKEN": os.getenv("TELEGRAM_BOT_TOKEN", "REPLACE_WITH_YOUR_TELEGRAM_BOT_TOKEN"),
    "TELEGRAM_CHAT_ID": os.getenv("TELEGRAM_CHAT_ID", "REPLACE_WITH_YOUR_TELEGRAM_CHAT_ID"),

    # Server bind settings.
    "HOST": os.getenv("HOST", "0.0.0.0"),
    "PORT": int(os.getenv("PORT", "8000")),

    # Optional shared-secret header check for the /webhook route. If set,
    # incoming requests must include a matching `X-Webhook-Secret` header.
    # Leave unset/empty to disable this check (not recommended in production).
    "WEBHOOK_SECRET": os.getenv("WEBHOOK_SECRET", ""),
}
