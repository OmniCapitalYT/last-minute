"""
Async push-notification dispatch via the Telegram Bot API.

Uses httpx.AsyncClient so the FastAPI event loop is never blocked while
waiting on the network round trip to Telegram.
"""

import logging

import httpx

from app.config import CONFIG

logger = logging.getLogger("boundary_arb.notifier")

TELEGRAM_API_URL = "https://api.telegram.org/bot{token}/sendMessage"


async def send_telegram_alert(message: str) -> bool:
    """
    Fire-and-report a Telegram message to the configured chat.
    Returns True on confirmed delivery, False otherwise (never raises --
    a notification failure should not crash the webhook response).
    """
    token = CONFIG["TELEGRAM_BOT_TOKEN"]
    chat_id = CONFIG["TELEGRAM_CHAT_ID"]

    if not token or token.startswith("REPLACE_WITH"):
        logger.warning("TELEGRAM_BOT_TOKEN is not configured -- skipping notification dispatch.")
        return False
    if not chat_id or chat_id.startswith("REPLACE_WITH"):
        logger.warning("TELEGRAM_CHAT_ID is not configured -- skipping notification dispatch.")
        return False

    url = TELEGRAM_API_URL.format(token=token)
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "Markdown",
    }

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(url, json=payload)
            response.raise_for_status()
        logger.info("Telegram alert dispatched successfully.")
        return True
    except httpx.HTTPStatusError as exc:
        logger.error("Telegram API rejected the request: %s - %s", exc.response.status_code, exc.response.text)
    except httpx.RequestError as exc:
        logger.error("Network error dispatching Telegram alert: %s", exc)
    return False
